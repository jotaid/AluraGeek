// URL base de la API
const API_URL = 'http://localhost:3001/products';

/**
 * Obtiene todos los productos de la API
 * @returns {Promise<Array>} Array de productos
 */
export const getProducts = async () => {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }
        const data = await response.json();
        console.log('Productos obtenidos:', data);
        return data;
    } catch (error) {
        console.error('Error al obtener productos:', error);
        throw error;
    }
};

/**
 * Crea un nuevo producto
 * @param {Object} productData - Datos del producto a crear
 * @returns {Promise<Object>} Producto creado
 */
export const createProduct = async (productData) => {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(productData)
        });
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Error al crear producto:', error);
        throw error;
    }
};

/**
 * Elimina un producto por su ID
 * @param {string|number} id - ID del producto a eliminar
 * @returns {Promise<boolean>} true si se eliminó correctamente
 */
export const deleteProduct = async (id) => {
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        });
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }
        return true;
    } catch (error) {
        console.error('Error al eliminar producto:', error);
        throw error;
    }
};
