import { getProducts, createProduct, deleteProduct } from '../services/product-services.js';

// Referencias a elementos del DOM
const productsContainer = document.getElementById('productsContainer');
const productForm = document.getElementById('productForm');
const searchInput = document.getElementById('searchInput');
const modal = document.getElementById('imageModal');
const modalImg = document.getElementById('modalImage');

let products = [];

// Función para mostrar el diálogo de confirmación de eliminación
const showDeleteConfirmation = (id) => {
    return new Promise((resolve) => {
        const dialogHTML = `
            <div class="delete-confirmation-overlay">
                <div class="delete-confirmation-dialog">
                    <div class="delete-confirmation-content">
                        <i class="fas fa-exclamation-triangle" style="color: #CF6679; font-size: 2rem; margin-bottom: 1rem;"></i>
                        <h3>¿Estás seguro?</h3>
                        <p>Esta acción eliminará el producto permanentemente.</p>
                        <div class="delete-confirmation-buttons">
                            <button class="btn-cancel">Cancelar</button>
                            <button class="btn-delete">Eliminar</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', dialogHTML);

        const overlay = document.querySelector('.delete-confirmation-overlay');
        const dialog = document.querySelector('.delete-confirmation-dialog');
        const cancelBtn = dialog.querySelector('.btn-cancel');
        const deleteBtn = dialog.querySelector('.btn-delete');

        requestAnimationFrame(() => {
            overlay.style.opacity = '1';
            dialog.style.transform = 'translateY(0)';
        });

        const closeDialog = (confirmed) => {
            overlay.style.opacity = '0';
            dialog.style.transform = 'translateY(-20px)';
            setTimeout(() => {
                overlay.remove();
                resolve(confirmed);
            }, 300);
        };

        cancelBtn.addEventListener('click', () => closeDialog(false));
        deleteBtn.addEventListener('click', () => closeDialog(true));
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) closeDialog(false);
        });
    });
};

// Función para actualizar un producto
const updateProduct = async (id, productData) => {
    try {
        const response = await fetch(`http://localhost:3001/products/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(productData)
        });
        if (!response.ok) throw new Error('Error al actualizar el producto');
        return await response.json();
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
};

// Función para mostrar el modal de edición
const showEditModal = (product) => {
    const editModal = document.getElementById('editModal');
    const editForm = document.getElementById('editForm');
    const closeBtn = editModal.querySelector('.modal-close');
    const cancelBtn = document.getElementById('cancelEdit');

    // Rellenar el formulario
    document.getElementById('editName').value = product.name;
    document.getElementById('editPrice').value = product.price;
    document.getElementById('editDescription').value = product.description || '';
    document.getElementById('editImage').value = product.image;

    // Mostrar modal
    editModal.style.display = 'flex';
    document.body.style.overflow = 'hidden';

    // Función para cerrar el modal
    const closeEditModal = () => {
        editModal.style.display = 'none';
        document.body.style.overflow = '';
    };

    // Manejar el envío del formulario
    editForm.onsubmit = async (e) => {
        e.preventDefault();
        
        const updatedProduct = {
            name: document.getElementById('editName').value,
            price: document.getElementById('editPrice').value,
            description: document.getElementById('editDescription').value,
            image: document.getElementById('editImage').value
        };

        try {
            await updateProduct(product.id, updatedProduct);
            await loadProducts();
            closeEditModal();
        } catch (error) {
            alert('Error al actualizar el producto');
        }
    };

    // Eventos para cerrar
    closeBtn.onclick = closeEditModal;
    cancelBtn.onclick = closeEditModal;
    editModal.onclick = (e) => {
        if (e.target === editModal) closeEditModal();
    };
};

// Función para crear la tarjeta de producto
const createProductCard = (product) => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
        <div class="product-image-container">
            <img src="${product.image}" alt="${product.name}" class="product-image">
        </div>
        <div class="product-info">
            <h3 class="product-name">${product.name}</h3>
            <p class="product-description">${product.description || 'Sin descripción'}</p>
            <p class="product-price">$${product.price}</p>
            <div class="card-actions">
                <button class="edit-btn" data-id="${product.id}">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="delete-btn" data-id="${product.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `;

    // Eventos de los botones
    const editBtn = card.querySelector('.edit-btn');
    editBtn.addEventListener('click', () => showEditModal(product));

    const img = card.querySelector('.product-image');
    img.addEventListener('click', () => openModal(product.image));

    const deleteBtn = card.querySelector('.delete-btn');
    deleteBtn.addEventListener('click', async () => {
        const confirmed = await showDeleteConfirmation(product.id);
        if (confirmed) {
            try {
                await deleteProduct(product.id);
                await loadProducts();
            } catch (error) {
                console.error('Error al eliminar:', error);
                alert('Error al eliminar el producto');
            }
        }
    });

    return card;
};

// Funciones para el modal de imagen
const openModal = (imageSrc) => {
    modalImg.src = imageSrc;
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
};

const closeModal = () => {
    modal.style.display = 'none';
    document.body.style.overflow = '';
};

// Cargar productos
const loadProducts = async () => {
    try {
        products = await getProducts();
        displayProducts(products);
    } catch (error) {
        console.error('Error al cargar productos:', error);
        productsContainer.innerHTML = '<p class="error-message">Error al cargar los productos</p>';
    }
};

// Mostrar productos
const displayProducts = (productsToDisplay) => {
    productsContainer.innerHTML = '';
    if (!productsToDisplay.length) {
        productsContainer.innerHTML = '<p class="no-products">No se encontraron productos</p>';
        return;
    }
    productsToDisplay.forEach(product => {
        productsContainer.appendChild(createProductCard(product));
    });
};

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    loadProducts();

    // Agregar modal de edición
    document.body.insertAdjacentHTML('beforeend', `
        <div id="editModal" class="modal edit-modal">
            <div class="modal-content">
                <button class="modal-close">&times;</button>
                <h2>Editar Producto</h2>
                <form id="editForm" class="edit-form">
                    <div class="form-group">
                        <label for="editName">Nombre del Producto</label>
                        <input type="text" id="editName" required>
                    </div>
                    <div class="form-group">
                        <label for="editPrice">Precio</label>
                        <input type="number" id="editPrice" required>
                    </div>
                    <div class="form-group">
                        <label for="editDescription">Descripción</label>
                        <textarea id="editDescription" rows="4" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="editImage">URL de la Imagen</label>
                        <input type="url" id="editImage" required>
                    </div>
                    <div class="button-container">
                        <button type="button" class="btn btn-secondary" id="cancelEdit">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    `);
});

productForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const productData = {
        name: document.getElementById('productName').value,
        price: document.getElementById('productPrice').value,
        description: document.getElementById('productDescription').value,
        image: document.getElementById('productImage').value
    };

    try {
        await createProduct(productData);
        await loadProducts();
        productForm.reset();
    } catch (error) {
        alert('Error al crear el producto');
    }
});

searchInput.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filtered = products.filter(product => 
        product.name.toLowerCase().includes(searchTerm) ||
        (product.description && product.description.toLowerCase().includes(searchTerm))
    );
    displayProducts(filtered);
});

// Eventos del modal de imagen
modal?.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
});
